# -*- coding: utf-8 -*-
"""
生成 H5 页面的夜景占位素材（程序化绘制，非实拍）。
正式上线前请用真实演出 / 产品图替换 assets/img 下的同名文件。
用法: python tools/make_placeholders.py
"""
import math
import os
import random

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "img")
os.makedirs(OUT, exist_ok=True)
random.seed(20261103)
np.random.seed(20261103)

CYAN = (86, 226, 255)
GOLD = (255, 190, 110)
VIOLET = (150, 130, 255)
PINK = (255, 120, 170)
WHITE = (235, 248, 255)


# ---------------------------------------------------------------- 基础工具
def vertical_gradient(w, h, stops):
    """stops: [(0.0,(r,g,b)), ...] -> float array HxWx3 (0..1)"""
    ys = np.linspace(0.0, 1.0, h)
    arr = np.zeros((h, 3), dtype=np.float32)
    for i, t in enumerate(ys):
        for j in range(len(stops) - 1):
            p0, c0 = stops[j]
            p1, c1 = stops[j + 1]
            if p0 <= t <= p1:
                f = (t - p0) / (p1 - p0) if p1 > p0 else 0.0
                arr[i] = [c0[k] + (c1[k] - c0[k]) * f for k in range(3)]
                break
    arr /= 255.0
    return np.repeat(arr[:, None, :], w, axis=1)


def add_radial(img, cx, cy, r, color, strength, power=2.2):
    h, w = img.shape[:2]
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.sqrt((x - cx) ** 2 + (y - cy) ** 2) / max(r, 1)
    g = np.clip(1.0 - d, 0.0, 1.0) ** power * strength
    col = np.array(color, dtype=np.float32) / 255.0
    for k in range(3):
        img[:, :, k] += g * col[k]


def add_stars(img, count=420, y_max=1.0, alpha=0.9):
    h, w = img.shape[:2]
    overlay = np.zeros((h, w, 3), dtype=np.float32)
    for _ in range(count):
        x = random.uniform(0, w)
        y = random.uniform(0, h * y_max)
        b = random.uniform(0.15, 1.0) ** 2 * alpha
        rad = random.uniform(0.4, 1.5)
        col = np.array(WHITE) / 255.0 * b
        x0, x1 = max(0, int(x - 2)), min(w, int(x + 3))
        y0, y1 = max(0, int(y - 2)), min(h, int(y + 3))
        yy, xx = np.mgrid[y0:y1, x0:x1]
        d = np.sqrt((xx - x) ** 2 + (yy - y) ** 2)
        m = np.clip(1.0 - d / (rad + 0.6), 0.0, 1.0)[..., None]
        overlay[y0:y1, x0:x1] += m * col
    return np.clip(img + overlay, 0, 1)


def city_silhouette(img, horizon, height=0.17, glow=(255, 138, 70), glow_strength=0.26):
    """在画面下方加城市天际线剪影 + 地面灯光（远/近两层）"""
    h, w = img.shape[:2]
    ground = int(h * 0.99)
    add_radial(img, w * 0.5, int(h * horizon), w * 0.95, glow, glow_strength, power=1.6)
    add_radial(img, w * 0.2, int(h * horizon), w * 0.6, (80, 130, 255), glow_strength * 0.65, power=2.0)
    add_radial(img, w * 0.82, int(h * horizon), w * 0.5, (255, 120, 60), glow_strength * 0.5, power=2.2)

    def layer_buildings(count, max_h, color, window_alpha, blur):
        layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        d = ImageDraw.Draw(layer)
        x = -w * 0.04
        for _ in range(count):
            bw = random.uniform(w * 0.025, w * 0.09)
            bh = random.uniform(max_h * 0.22, max_h)
            top = ground - bh
            d.rectangle([x, top, x + bw, ground], fill=(*color, 255))
            if random.random() < 0.45:
                ax = x + bw * random.uniform(0.25, 0.75)
                d.line([ax, top, ax, top - random.uniform(h * 0.008, h * 0.03)], fill=(*color, 255),
                       width=max(1, int(w * 0.0022)))
            # 航空障碍灯
            if random.random() < 0.35:
                d.ellipse([x + bw / 2 - 1.6, top - 1.6, x + bw / 2 + 1.6, top + 1.6], fill=(255, 60, 55, 200))
            # 窗户
            cols = max(1, int(bw / (w * 0.014)))
            rows = max(1, int(bh / (h * 0.015)))
            for r in range(rows):
                for c in range(cols):
                    if random.random() < 0.34:
                        wx = x + 2 + c * (w * 0.014)
                        wy = top + 4 + r * (h * 0.015)
                        if wx > x + bw - 2:
                            continue
                        warm = random.random() < 0.75
                        a = random.randint(28, window_alpha)
                        cc = (255, 205, 135, a) if warm else (150, 205, 255, int(a * 0.8))
                        d.rectangle([wx, wy, wx + max(1, w * 0.0045), wy + max(1, h * 0.0045)], fill=cc)
            x += bw + random.uniform(w * 0.004, w * 0.025)
        return layer.filter(ImageFilter.GaussianBlur(blur))

    distant = layer_buildings(26, h * height * 0.8, (10, 16, 28), 70, 0.8)
    near = layer_buildings(16, h * height, (3, 5, 9), 120, 0.5)
    base = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8)).convert("RGBA")
    base.alpha_composite(distant)
    base.alpha_composite(near)
    return np.asarray(base.convert("RGB")).astype(np.float32) / 255.0


def vignette(img, strength=0.42):
    h, w = img.shape[:2]
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    nx = (x - w / 2) / (w / 2)
    ny = (y - h / 2) / (h / 2)
    r = np.sqrt(nx ** 2 + ny ** 2) / math.sqrt(2)
    v = 1.0 - np.clip(r, 0, 1) ** 2 * strength
    return img * v[..., None]


def grain(img, amount=0.018):
    h, w = img.shape[:2]
    n = np.random.normal(0, 1, (h, w, 1)).astype(np.float32) * amount
    return np.clip(img + n, 0, 1)


def screen_dots(base, points, glow_r=(7, 16), core_r=(1.2, 2.6), glow_gain=0.85, blur=7):
    """points: [(x, y, color_tuple, brightness)] -> 用 screen 混合出灯光点阵"""
    w, h = base.size
    glow = Image.new("RGB", (w, h), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    core = Image.new("RGB", (w, h), (0, 0, 0))
    cd = ImageDraw.Draw(core)
    for x, y, col, br in points:
        gr = random.uniform(*glow_r)
        gcol = tuple(int(min(255, c * br * glow_gain)) for c in col)
        gd.ellipse([x - gr, y - gr, x + gr, y + gr], fill=gcol)
        cr = random.uniform(*core_r)
        ccol = tuple(int(min(255, c * (0.55 + 0.45 * br))) for c in col)
        ccol = tuple(int(min(255, c * 0.35 + 255 * 0.55)) for c in ccol)
        cd.ellipse([x - cr, y - cr, x + cr, y + cr], fill=ccol)
    glow = glow.filter(ImageFilter.GaussianBlur(blur))
    core = core.filter(ImageFilter.GaussianBlur(0.7))
    out = ImageChops.screen(base, glow)
    out = ImageChops.screen(out, core)
    return out


def mask_points(mask, density, color_a, color_b, jitter=0.6):
    """按 mask 像素采样出点阵"""
    arr = np.asarray(mask)
    ys, xs = np.where(arr > 100)
    if len(xs) == 0:
        return []
    n = max(1, int(len(xs) * density))
    idx = np.random.choice(len(xs), size=min(n, len(xs)), replace=False)
    pts = []
    for i in idx:
        x = float(xs[i]) + random.uniform(-jitter, jitter)
        y = float(ys[i]) + random.uniform(-jitter, jitter)
        t = np.clip((x / mask.width) * 0.7 + (y / mask.height) * 0.3, 0, 1)
        col = tuple(int(color_a[k] + (color_b[k] - color_a[k]) * t) for k in range(3))
        pts.append((x, y, col, random.uniform(0.55, 1.0)))
    return pts


def new_sky(w, h, horizon=0.8, warm=True):
    img = vertical_gradient(w, h, [
        (0.00, (2, 4, 10)),
        (0.35, (5, 11, 24)),
        (0.62, (8, 20, 42)),
        (0.80, (10, 26, 48)),
        (1.00, (4, 9, 18)),
    ])
    add_radial(img, w * 0.72, h * 0.18, w * 0.75, (30, 80, 160), 0.42, power=2.4)
    add_radial(img, w * 0.16, h * 0.52, w * 0.6, (60, 40, 130), 0.16, power=2.6)
    if warm:
        add_radial(img, w * 0.5, h * 0.86, w * 0.8, (255, 150, 80), 0.20, power=2.4)
    img = add_stars(img, count=int(w * h / 5200), y_max=0.92)
    return img


def finish(img, path, quality=84):
    img = grain(vignette(np.clip(img, 0, 1), 0.38), 0.016)
    im = Image.fromarray((img * 255).astype(np.uint8))
    im.save(path, quality=quality, optimize=True, progressive=True)
    print("saved", os.path.basename(path), im.size, os.path.getsize(path) // 1024, "KB")


def save(np_img, name, quality=84):
    finish(np_img, os.path.join(OUT, name), quality)


# ---------------------------------------------------------------- 形状
def mask_quadcopter(w, h, s=1.0, guards=True, gear=True):
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    cx, cy = w * 0.5, h * 0.52
    body_r = w * 0.075 * s
    arm = w * 0.20 * s
    d.ellipse([cx - body_r, cy - body_r * 0.8, cx + body_r, cy + body_r * 0.8], fill=255)
    d.ellipse([cx - body_r * 0.42, cy + body_r * 0.55, cx + body_r * 0.42, cy + body_r * 1.5], fill=255)
    rotors = []
    for ang in (45, 135, 225, 315):
        a = math.radians(ang)
        rx, ry = cx + arm * math.cos(a), cy + arm * math.sin(a) * 0.82
        d.line([cx, cy, rx, ry], fill=255, width=max(3, int(w * 0.012 * s)))
        d.ellipse([rx - w * 0.038 * s, ry - w * 0.038 * s, rx + w * 0.038 * s, ry + w * 0.038 * s], fill=255)
        rr = w * 0.105 * s
        d.ellipse([rx - rr, ry - rr * 0.42, rx + rr, ry + rr * 0.42], outline=255, width=max(2, int(w * 0.007 * s)))
        rotors.append((rx, ry))
    if guards:
        for rx, ry in rotors:
            gr = w * 0.115 * s
            d.ellipse([rx - gr, ry - gr * 0.62, rx + gr, ry + gr * 0.62], outline=255, width=max(2, int(w * 0.006 * s)))
    if gear:
        gw = w * 0.13 * s
        gy = cy + h * 0.13 * s
        d.line([cx - gw, gy, cx + gw, gy], fill=255, width=max(3, int(w * 0.011 * s)))
        d.line([cx - gw * 0.55, cy + body_r * 0.9, cx - gw * 0.55, gy], fill=255, width=max(3, int(w * 0.010 * s)))
        d.line([cx + gw * 0.55, cy + body_r * 0.9, cx + gw * 0.55, gy], fill=255, width=max(3, int(w * 0.010 * s)))
    return m


def mask_shape(name, w, h):
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    cx, cy = w * 0.5, h * 0.45
    r = min(w, h) * 0.20
    if name == "heart":
        d.ellipse([cx - r, cy - r * 0.9, cx, cy + r * 0.2], fill=255)
        d.ellipse([cx, cy - r * 0.9, cx + r, cy + r * 0.2], fill=255)
        d.polygon([(cx - r * 0.98, cy - r * 0.12), (cx + r * 0.98, cy - r * 0.12), (cx, cy + r * 1.35)], fill=255)
    elif name == "star":
        pts = []
        for i in range(10):
            ang = -math.pi / 2 + i * math.pi / 5
            rad = r * (1.0 if i % 2 == 0 else 0.42)
            pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
        d.polygon(pts, fill=255)
    elif name == "crown":
        base = cy + r * 0.55
        d.polygon([(cx - r, base), (cx - r * 0.85, cy - r * 0.9), (cx - r * 0.3, cy - r * 0.05),
                   (cx, cy - r * 1.1), (cx + r * 0.3, cy - r * 0.05), (cx + r * 0.85, cy - r * 0.9),
                   (cx + r, base)], fill=255)
        d.rectangle([cx - r, base, cx + r, base + r * 0.22], fill=255)
    elif name == "mountain":
        d.polygon([(cx - r * 1.2, cy + r * 0.7), (cx - r * 0.25, cy - r * 0.75),
                   (cx + r * 0.5, cy + r * 0.7)], fill=255)
        d.polygon([(cx - r * 0.15, cy + r * 0.7), (cx + r * 0.55, cy - r * 0.35),
                   (cx + r * 1.25, cy + r * 0.7)], fill=255)
    elif name == "city":
        base = cy + r * 0.75
        towers = [(-1.15, 0.55, 0.35), (-0.7, 0.95, 0.28), (-0.25, 0.72, 0.34),
                  (0.15, 1.12, 0.3), (0.55, 0.6, 0.36), (0.95, 0.82, 0.28)]
        for tx, th, tw in towers:
            x0 = cx + tx * r
            d.rectangle([x0, base - r * th, x0 + r * tw, base], fill=255)
        for tx, th, tw in towers[1::2]:
            x0 = cx + tx * r + r * tw * 0.5
            d.line([x0, base - r * th, x0, base - r * th - r * 0.28], fill=255, width=5)
    elif name == "ring":
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=255, width=max(4, int(r * 0.10)))
        d.ellipse([cx - r * 1.35, cy - r * 0.32, cx + r * 1.35, cy + r * 0.34], outline=255, width=max(3, int(r * 0.07)))
    elif name == "note":
        d.rectangle([cx - r * 0.15, cy - r * 0.9, cx - r * 0.05, cy + r * 0.55], fill=255)
        d.rectangle([cx + r * 0.55, cy - r * 1.05, cx + r * 0.65, cy + r * 0.42], fill=255)
        d.polygon([(cx - r * 0.15, cy - r * 0.9), (cx + r * 0.65, cy - r * 1.05),
                   (cx + r * 0.65, cy - r * 0.78), (cx - r * 0.15, cy - r * 0.62)], fill=255)
        d.ellipse([cx - r * 0.55, cy + r * 0.38, cx - r * 0.02, cy + r * 0.7], fill=255)
        d.ellipse([cx + r * 0.15, cy + r * 0.25, cx + r * 0.68, cy + r * 0.57], fill=255)
    return m


def ribbon_points(w, h, color_a, color_b, phase=0.0, n=520, bands=3):
    pts = []
    for b in range(bands):
        for i in range(n // bands):
            t = i / max(1, (n // bands - 1))
            x = w * (0.08 + 0.84 * t)
            y = h * (0.58 - 0.20 * math.sin(t * math.pi * 1.15 + phase) + (b - 1) * 0.055
                     + 0.018 * math.sin(t * 12 + b))
            tt = min(1.0, max(0.0, t * 0.8 + b * 0.1))
            col = tuple(int(color_a[k] + (color_b[k] - color_a[k]) * tt) for k in range(3))
            pts.append((x + random.uniform(-2.5, 2.5), y + random.uniform(-2.5, 2.5), col,
                        random.uniform(0.5, 1.0)))
    return pts


# ---------------------------------------------------------------- 页面素材
def make_hero():
    w, h = 1080, 1920
    img = new_sky(w, h, horizon=0.86)
    add_radial(img, w * 0.5, h * 0.85, w * 1.2, (255, 160, 80), 0.34, power=1.7)
    add_radial(img, w * 0.5, h * 0.55, w * 0.8, (60, 120, 220), 0.14, power=2.4)

    base = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    # 五层“灯光穹顶”，像一场正在展开的编队
    cx, cy = w * 0.5, h * 0.82
    palette = [(CYAN, GOLD), (GOLD, PINK), (VIOLET, CYAN), (CYAN, PINK), (GOLD, CYAN)]
    for k in range(5):
        ca, cb = palette[k]
        r = h * (0.20 + 0.115 * k)
        pts = []
        for t in np.linspace(math.pi * 1.06, math.pi * 1.94, 210):
            x = cx + r * math.cos(t)
            y = cy + r * math.sin(t) * 0.92
            tt = np.clip((t - math.pi) / (math.pi) + 0.5, 0, 1)
            col = tuple(int(ca[i] + (cb[i] - ca[i]) * tt) for i in range(3))
            pts.append((x + random.uniform(-3, 3), y + random.uniform(-3, 3), col, random.uniform(0.5, 1.0)))
        # 零星漂浮的飞机
        for _ in range(14):
            pts.append((random.uniform(w * 0.08, w * 0.92), random.uniform(h * 0.18, h * 0.55),
                        random.choice([CYAN, GOLD, VIOLET]), random.uniform(0.3, 0.7)))
        base = screen_dots(base, pts, glow_r=(9, 22), core_r=(1.6, 3.6), glow_gain=0.68, blur=10)
    img = np.asarray(base).astype(np.float32) / 255.0

    # 底部城市 + 人群光斑
    img = city_silhouette(img, 0.9, height=0.12, glow=(255, 140, 60), glow_strength=0.34)
    add_radial(img, w * 0.3, h * 0.965, w * 0.4, (255, 200, 120), 0.20, power=2.2)
    save(img, "hero.jpg", quality=82)


def make_product(name, color_a, color_b, variant=0):
    w, h = 800, 600
    img = new_sky(w, h, horizon=0.95)
    add_radial(img, w * 0.5, h * 0.52, w * 0.55, color_a, 0.10, power=2.0)
    m = mask_quadcopter(w, h, s=1.15, guards=variant != 1, gear=variant != 2)
    pts = mask_points(m, 0.13, color_a, color_b)
    base = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    base = screen_dots(base, pts, glow_r=(5, 13), core_r=(1.0, 2.2), glow_gain=0.9, blur=6)
    # 地面光晕
    img = np.asarray(base).astype(np.float32) / 255.0
    add_radial(img, w * 0.5, h * 0.86, w * 0.5, (255, 170, 90), 0.16, power=2.0)
    save(img, f"product-{name}.jpg", quality=85)


def make_scene(name, shape, horizon=0.72):
    w, h = 800, 1000
    img = new_sky(w, h, horizon=horizon)
    add_radial(img, w * 0.5, h * horizon, w * 0.85, (255, 150, 70), 0.24, power=1.9)
    m = mask_shape(shape, w, h)
    m = m.resize((w, h), Image.LANCZOS)
    pts = mask_points(m, 0.10, CYAN, GOLD)
    base = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    base = screen_dots(base, pts, glow_r=(6, 15), core_r=(1.2, 2.8), glow_gain=0.8, blur=7)
    img = np.asarray(base).astype(np.float32) / 255.0
    img = city_silhouette(img, horizon, height=0.1, glow=(255, 140, 60), glow_strength=0.26)
    save(img, f"scene-{name}.jpg", quality=84)


def make_case(name, color_a, color_b, mode="ribbon"):
    w, h = 960, 540
    img = new_sky(w, h, horizon=0.88)
    add_radial(img, w * 0.5, h * 0.86, w * 0.9, (255, 145, 65), 0.25, power=1.9)
    base = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    if mode == "ribbon":
        pts = ribbon_points(w, h, color_a, color_b, phase=random.uniform(0, 2), n=420)
    elif mode == "globe":
        pts = []
        cx, cy, r = w * 0.5, h * 0.45, h * 0.31
        for k, lat in enumerate(np.linspace(-3 / 4, 3 / 4, 7)):
            ry = r * math.sqrt(max(0.05, 1 - lat * lat))
            for t in np.linspace(0, 2 * math.pi, 90):
                pts.append((cx + ry * math.cos(t), cy + lat * r + ry * math.sin(t) * 0.26,
                            color_a if k % 2 else color_b, 0.8))
        for k, lon in enumerate(np.linspace(0, math.pi, 6)):
            rw = r * abs(math.cos(lon))
            for t in np.linspace(0, 2 * math.pi, 80):
                pts.append((cx + rw * math.cos(t), cy + r * math.sin(t),
                            color_b if k % 2 else color_a, 0.7))
    elif mode == "burst":
        pts = []
        cx, cy = w * 0.5, h * 0.5
        for k in range(46):
            ang = k * 2 * math.pi / 46
            for rr in np.linspace(0.08, 1.0, 9):
                r = h * 0.34 * rr
                pts.append((cx + r * math.cos(ang) * 1.3, cy + r * math.sin(ang),
                            color_a if k % 2 else color_b, 0.75))
    else:  # arc
        pts = []
        cx, cy = w * 0.5, h * 0.95
        for k in range(3):
            r = h * (0.55 + k * 0.16)
            for t in np.linspace(math.pi * 1.08, math.pi * 1.92, 130):
                pts.append((cx + r * math.cos(t), cy + r * math.sin(t),
                            color_a if k % 2 else color_b, 0.8))
    base = screen_dots(base, pts, glow_r=(6, 15), core_r=(1.2, 2.6), glow_gain=0.8, blur=7)
    img = np.asarray(base).astype(np.float32) / 255.0
    img = city_silhouette(img, 0.9, height=0.08, glow=(255, 140, 60), glow_strength=0.22)
    save(img, f"case-{name}.jpg", quality=84)


if __name__ == "__main__":
    make_hero()
    make_product("modelx", CYAN, GOLD, 0)
    make_product("agilebee", GOLD, CYAN, 1)
    make_product("effects", PINK, GOLD, 2)
    make_product("ground", VIOLET, CYAN, 0)
    make_scene("city", "city")
    make_scene("scenic", "mountain")
    make_scene("brand", "ring")
    make_scene("celebration", "star")
    make_scene("wedding", "heart", horizon=0.78)
    make_scene("idol", "crown", horizon=0.78)
    make_case("spring", GOLD, PINK, "burst")
    make_case("record", CYAN, GOLD, "globe")
    make_case("guinness", GOLD, VIOLET, "ribbon")
    make_case("tju", CYAN, VIOLET, "arc")
