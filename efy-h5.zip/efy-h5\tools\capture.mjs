import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";

const ROOT = path.resolve(process.argv[2] || ".");
const OUT = path.join(ROOT, "shots");
fs.mkdirSync(OUT, { recursive: true });

const EDGE = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";
const PORT = 9411;
const PROFILE = path.join(ROOT, ".tmp-edge-profile");
const PAGE = "file:///" + path.join(ROOT, "index.html").replace(/\\/g, "/");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const edge = spawn(
  EDGE,
  [
    "--headless=new",
    `--remote-debugging-port=${PORT}`,
    `--user-data-dir=${PROFILE}`,
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-gpu",
    "--hide-scrollbars",
    "--force-device-scale-factor=1",
    "about:blank",
  ],
  { stdio: "ignore" }
);

let ws;
let msgId = 0;
const pending = new Map();
const events = [];
const consoleErrors = [];
let loadResolvers = [];

function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++msgId;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
  });
}

async function waitForTarget() {
  for (let i = 0; i < 80; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`);
      const list = await res.json();
      const page = list.find((t) => t.type === "page");
      if (page) return page;
    } catch {}
    await sleep(250);
  }
  throw new Error("Edge debugging target not found");
}

function onceLoad() {
  return new Promise((resolve) => loadResolvers.push(resolve));
}

async function connect() {
  const target = await waitForTarget();
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.onopen = resolve;
    ws.onerror = reject;
  });
  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id);
      pending.delete(msg.id);
      if (msg.error) reject(new Error(msg.error.message));
      else resolve(msg.result);
      return;
    }
    events.push(msg);
    if (msg.method === "Page.loadEventFired") {
      const resolvers = loadResolvers;
      loadResolvers = [];
      resolvers.forEach((r) => r());
    }
    if (msg.method === "Runtime.exceptionThrown") {
      consoleErrors.push("[exception] " + (msg.params.exceptionDetails?.text || "unknown"));
    }
    if (msg.method === "Runtime.consoleAPICalled" && msg.params.type === "error") {
      consoleErrors.push("[console] " + msg.params.args.map((a) => a.value ?? a.description).join(" "));
    }
    if (msg.method === "Log.entryAdded" && msg.params.entry.level === "error") {
      consoleErrors.push("[log] " + msg.params.entry.text);
    }
  };
}

async function setViewport(width, height, mobile = true, scale = 2) {
  await send("Emulation.setDeviceMetricsOverride", {
    width,
    height,
    deviceScaleFactor: scale,
    mobile,
  });
}

async function navigate(url) {
  const loaded = onceLoad();
  await send("Page.navigate", { url });
  await loaded;
  await sleep(900);
}

async function evaluate(expression, awaitPromise = false) {
  const result = await send("Runtime.evaluate", {
    expression,
    awaitPromise,
    returnByValue: true,
    userGesture: true,
  });
  if (result.exceptionDetails) {
    throw new Error(result.exceptionDetails.text + " " + (result.exceptionDetails.exception?.description || ""));
  }
  return result.result?.value;
}

async function screenshot(name) {
  const result = await send("Page.captureScreenshot", { format: "png", fromSurface: true });
  fs.writeFileSync(path.join(OUT, name), Buffer.from(result.data, "base64"));
  console.log("shot:", name);
}

async function scrollTo(selector, offset = 0) {
  await evaluate(
    `(()=>{const el=document.querySelector(${JSON.stringify(selector)}); if(!el) return 'missing'; const y=el.getBoundingClientRect().top+window.scrollY-24+${offset}; window.scrollTo(0,y); return y;})()`
  );
  await sleep(650);
}

async function hideScrollAnimations() {
  await evaluate(`document.documentElement.style.scrollBehavior='auto';`);
}

async function main() {
  await connect();
  await send("Page.enable");
  await send("Runtime.enable");
  await send("Log.enable");
  await send("Emulation.setEmulatedMedia", {
    features: [{ name: "prefers-reduced-motion", value: "reduce" }],
  });

  // ---------- Mobile 390 ----------
  await setViewport(390, 844, true, 2);
  await navigate(PAGE);
  await hideScrollAnimations();

  await screenshot("m-01-hero.png");

  await scrollTo("#stats", 0);
  await screenshot("m-02-stats.png");

  await scrollTo("#consult", 0);
  await screenshot("m-03-consult-top.png");
  await evaluate("window.scrollBy(0, 640)");
  await sleep(500);
  await screenshot("m-04-consult-form.png");
  await evaluate("window.scrollBy(0, 680)");
  await sleep(500);
  await screenshot("m-05-consult-bottom.png");

  await scrollTo("#products", 0);
  await screenshot("m-06-products.png");
  await evaluate("window.scrollBy(0, 560)");
  await sleep(400);
  await screenshot("m-07-products-2.png");

  await scrollTo("#scenes", 0);
  await screenshot("m-08-scenes.png");
  await evaluate("window.scrollBy(0, 620)");
  await sleep(400);
  await screenshot("m-09-scenes-2.png");

  await scrollTo("#scale", 0);
  await screenshot("m-10-scale.png");
  await scrollTo(".record", 0);
  await screenshot("m-11-record.png");

  await scrollTo("#cases", 0);
  await screenshot("m-12-cases.png");

  await scrollTo("#process", 0);
  await screenshot("m-13-process.png");

  await scrollTo("#why", 0);
  await screenshot("m-14-why.png");

  await scrollTo("#about", 0);
  await screenshot("m-15-about.png");

  await scrollTo("#faq", 0);
  await screenshot("m-16-faq.png");

  await scrollTo("#final", 0);
  await screenshot("m-17-final.png");

  await evaluate("window.scrollTo(0, document.body.scrollHeight)");
  await sleep(700);
  await screenshot("m-18-footer.png");

  // FAQ 交互
  await scrollTo("#faq", 0);
  await evaluate("document.querySelector('.faq-item__q').click()");
  await sleep(600);
  await screenshot("m-19-faq-open.png");

  // 产品咨询 -> 兴趣条
  await scrollTo("#products", 0);
  await evaluate("document.querySelectorAll('[data-interest]')[0].click()");
  await sleep(900);
  await screenshot("m-20-interest.png");
  const interestState = await evaluate(`({
    hidden: document.getElementById('interestBar').hidden,
    display: getComputedStyle(document.getElementById('interestBar')).display,
    text: document.getElementById('interestText').textContent,
    focused: document.activeElement && document.activeElement.id
  })`);
  console.log("INTEREST:", JSON.stringify(interestState));

  // 场景快捷选择
  await scrollTo("#scenes", 0);
  await evaluate("document.querySelectorAll('[data-scene]')[2].click()");
  await sleep(900);
  const sceneState = await evaluate(
    `[...document.querySelectorAll('.chips[data-group="scenes"] .chip[aria-pressed="true"]')].map(c=>c.dataset.value)`
  );
  console.log("SCENE:", JSON.stringify(sceneState));

  // 表单交互
  await scrollTo("#consult", 0);
  await evaluate(`(()=>{
    document.getElementById('f-name').value='测试用户';
    document.getElementById('f-name').dispatchEvent(new Event('input',{bubbles:true}));
    window.EFYBridge = { getPhoneNumber: function(){ return '13912345678'; } };
    document.getElementById('fillPhone').click();
    const a=document.getElementById('f-agree'); a.checked=true; a.dispatchEvent(new Event('change',{bubbles:true}));
    const chips=[...document.querySelectorAll('.chips[data-group="need"] .chip')];
    chips[0].click();
    const fleet=[...document.querySelectorAll('.chips[data-group="fleet"] .chip')];
    fleet[1].click();
    return true;
  })()`);
  await sleep(500);
  const bridgeState = await evaluate(`({
    phone: document.getElementById('f-phone').value,
    interest: document.getElementById('f-interest').value,
    barVisible: !document.getElementById('interestBar').hidden
  })`);
  console.log("BRIDGE:", JSON.stringify(bridgeState));
  await evaluate("document.getElementById('sendCode').click()");
  await sleep(900);
  const smsState = await evaluate(`({
    phone: document.getElementById('f-phone').value,
    btnText: document.getElementById('sendCode').textContent,
    btnDisabled: document.getElementById('sendCode').disabled
  })`);
  console.log("SMS:", JSON.stringify(smsState));
  await evaluate(`(()=>{
    const c=document.getElementById('f-code'); c.value='123456'; c.dispatchEvent(new Event('input',{bubbles:true}));
    const p=document.getElementById('f-phone'); p.value='13800138000'; p.dispatchEvent(new Event('input',{bubbles:true}));
    return true;
  })()`);
  await evaluate("window.scrollBy(0, 600)");
  await sleep(400);
  await screenshot("m-21-form-filled.png");
  await evaluate("document.getElementById('leadForm').requestSubmit()");
  await sleep(1600);
  await screenshot("m-22-success.png");

  const modalState = await evaluate(`({
    successOpen: !document.getElementById('successModal').hidden,
    meta: document.getElementById('successMeta').innerText,
    status: document.getElementById('formStatus').textContent,
    stored: JSON.parse(localStorage.getItem('efy_h5_leads_v1')||'[]').length
  })`);
  console.log("FORM RESULT:", JSON.stringify(modalState));

  // 关闭成功弹窗，打开案例弹窗
  await evaluate("document.querySelector('#successModal .modal__close').click()");
  await sleep(400);
  await scrollTo("#cases", 0);
  await evaluate("document.querySelector('.case-card').click()");
  await sleep(1200);
  await screenshot("m-23-case-modal.png");

  const caseState = await evaluate(`({
    open: !document.getElementById('caseModal').hidden,
    fallbackVisible: !document.getElementById('caseModalFallback').hidden,
    loaderVisible: !document.getElementById('caseModalLoader').hidden
  })`);
  console.log("CASE RESULT:", JSON.stringify(caseState));
  await evaluate("document.querySelector('#caseModal .modal__close').click()");
  await sleep(300);

  // 隐私弹层
  await evaluate("document.querySelector('[data-open-modal=privacyModal]').click()");
  await sleep(500);
  await screenshot("m-24-privacy.png");
  await evaluate("document.querySelector('#privacyModal [data-close-modal]').click()");
  await sleep(300);

  // 空表单校验
  await scrollTo("#consult", 0);
  await evaluate("document.getElementById('leadForm').requestSubmit()");
  await sleep(400);
  await screenshot("m-25-validation.png");
  const validation = await evaluate(`({
    errors: [...document.querySelectorAll('.field.has-error .field__error, #err-agree')].map(e=>e.textContent).filter(Boolean),
    status: document.getElementById('formStatus').textContent
  })`);
  console.log("VALIDATION:", JSON.stringify(validation));

  // ---------- Small phone 360 ----------
  await setViewport(360, 800, true, 2);
  await navigate(PAGE);
  const overflow360 = await evaluate(`({
    innerWidth: innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
    interestDisplay: getComputedStyle(document.getElementById('interestBar')).display
  })`);
  console.log("OVERFLOW 360:", JSON.stringify(overflow360));
  await screenshot("s-01-hero.png");
  await scrollTo("#consult", 0);
  await screenshot("s-02-consult.png");
  await scrollTo("#products", 0);
  await screenshot("s-03-products.png");
  await scrollTo("#scenes", 0);
  await screenshot("s-04-scenes.png");

  // ---------- Desktop 1280 ----------
  await setViewport(1280, 900, false, 1);
  await navigate(PAGE);
  await screenshot("d-01-hero.png");
  await scrollTo("#consult", 0);
  await screenshot("d-02-consult.png");
  await scrollTo("#products", 0);
  await screenshot("d-03-products.png");
  await scrollTo("#scenes", 0);
  await screenshot("d-04-scenes.png");
  await scrollTo("#cases", 0);
  await screenshot("d-05-cases.png");

  const summary = await evaluate(`({
    title: document.title,
    width: innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
    bodyHeight: document.body.scrollHeight,
    revealHidden: document.querySelectorAll('.reveal:not(.is-visible)').length,
    config: window.EFY_H5 ? 'ok' : 'missing'
  })`);
  console.log("SUMMARY:", JSON.stringify(summary));
  console.log("CONSOLE ERRORS:", consoleErrors.length ? JSON.stringify(consoleErrors, null, 2) : "none");

  ws.close();
  edge.kill();
}

main().catch((error) => {
  console.error("CAPTURE FAILED", error);
  try { edge.kill(); } catch {}
  process.exit(1);
});
