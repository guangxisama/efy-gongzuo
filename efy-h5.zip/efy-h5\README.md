# 一飞智控 EFY · 无人机集群表演 H5（留资版）

移动端优先的**单页 H5 展示 + 留资页面**，用于向城市文旅、景区、品牌与大型活动客户展示一飞智控的无人机集群表演能力，并收集销售线索。

页面结构参考同行「大漠大」的无人机表演 H5，但内容、视觉、文案与交互均为重新设计；所有数据来自一飞智控官网与公开报道（见第 8 节）。

- **纯静态**：HTML + CSS + 原生 JS，无框架、无构建、无外部字体/请求
- **直接可用**：双击 `index.html` 即可打开；也可以部署到任意静态服务器
- **可替换**：图片、视频按约定文件名放入 `assets/` 即可，不写代码
- **可留资**：表单校验、验证码倒计时、接口提交、成功弹层、埋点齐全
- **适配手机**：iOS 安全区、微信内打开、横屏兜底、`prefers-reduced-motion`

![首屏](preview/01-hero.jpg)
![留资表单](preview/02-form.jpg)
![产品矩阵](preview/03-products.jpg)

---

## 1. 快速开始

### 方式 A：直接打开（最快）

双击 `index.html`，用 Chrome / Edge / Safari 打开即可。视频、图片、JS 都使用相对路径，`file://` 下也能正常工作。

### 方式 B：本地静态服务器（推荐预览视频）

```bash
cd efy-h5
python -m http.server 8000
# 浏览器访问 http://127.0.0.1:8000/
```

### 手机预览

- 电脑和手机连同一 Wi-Fi，用手机访问 `http://<电脑局域网 IP>:8000/`；
- 或把整个 `efy-h5` 目录上传到任意静态托管（OSS / COS / Vercel / Netlify / Nginx）后访问。

> 建议在微信内置浏览器和 iOS Safari 各验证一遍，尤其是视频自动播放与安全区。

---

## 2. 目录结构

```text
efy-h5/
├── index.html                 # 页面结构（所有文案都在这里）
├── README.md                  # 本文件
├── docs/
│   └── content-plan.md        # 内容策划：分屏文案、表单设计、数据口径
├── assets/
│   ├── css/style.css          # 设计系统与响应式样式
│   ├── js/
│   │   ├── config.js          # ★ 上线前主要改这里：电话/邮箱/接口/短信
│   │   └── app.js             # 表单、弹层、滚动动效、视频兜底、埋点
│   ├── img/                   # 图片素材（当前为程序生成的占位图）
│   └── video/                 # 视频素材（当前为空，放入即自动生效）
│       └── README.md          # 视频命名与编码说明
├── preview/                   # 页面预览图（来自无头浏览器截图）
└── tools/
    ├── make_placeholders.py   # 生成占位夜景图的脚本（可选）
    └── capture.mjs            # 无头浏览器截图 + 交互自检脚本（可选）
```

---

## 3. 页面结构

| 区块 | 作用 | 主要交互 |
| --- | --- | --- |
| 首屏 Hero | 情绪主张 + 双 CTA + 数据 | 播放案例 / 滚动到表单 |
| 案例跑马灯 | 快速背书 | 自动横向滚动 |
| 数据条 | 规模可信度 | 数字滚动 |
| 留资表单 | **核心转化** | 一键填写、验证码、校验、接口提交、成功弹层 |
| 产品矩阵 | 产品与自研能力 | 点击产品 → 表单预填意向产品 |
| 应用场景 | 场景代入 | 点击场景 → 表单预选场景 |
| 演出规模 | 预算/规模匹配 | 横向滑动三档 + 33,615 架纪录现场 |
| 演出案例 | 视频说服 | 自动识别 `case-*.mp4`，缺省优雅兜底 |
| 服务流程 | 降低决策风险 | 横向滑动 8 步 |
| 我们的优势 | 技术与经验 | 渐入动效 |
| 关于一飞 | 公司资质 | 外链官网 |
| FAQ | 处理异议 | 手风琴展开 |
| 底部 CTA / 联系方式 | 直接转化 | 电话、邮箱、二维码 |
| 固定底栏 | 随时转化 | 进入表单区自动隐藏 |

完整文案与策划思路见 [`docs/content-plan.md`](docs/content-plan.md)。

---

## 4. 图片替换清单

所有图片都在 `assets/img/`，**用同名文件覆盖即可**，无需改代码。建议统一压暗、低饱和，保留夜空氛围。

| 文件名 | 尺寸建议 | 使用位置 | 替换建议 |
| --- | --- | --- | --- |
| `hero.jpg` | 1080 × 1920（9:16） | 首屏海报 / 视频封面 | 夜间编队实拍 + 城市天际线，建议留出中部文字区 |
| `product-modelx.jpg` | 800 × 600（4:3） | MODEL X 产品卡 | 产品实拍或官方渲染图 |
| `product-agilebee.jpg` | 800 × 600 | AGILE BEE III 产品卡 | 同上 |
| `product-effects.jpg` | 800 × 600 | 特效模块产品卡 | 冷焰火 / 孔明灯实拍 |
| `product-ground.jpg` | 800 × 600 | 地面系统产品卡 | 充电基站 / 地面站 |
| `scene-city.jpg` | 800 × 1000（4:5） | 城市文旅场景 | 城市地标上空编队 |
| `scene-scenic.jpg` | 800 × 1000 | 景区驻场 | 景区夜游实拍 |
| `scene-brand.jpg` | 800 × 1000 | 品牌发布 | 品牌 LOGO / 空中广告 |
| `scene-celebration.jpg` | 800 × 1000 | 大型庆典 | 大型活动航拍 |
| `scene-wedding.jpg` | 800 × 1000 | 婚庆表白 | 心形 / 求婚画面 |
| `scene-idol.jpg` | 800 × 1000 | 明星应援 | 应援现场 |
| `case-spring.jpg` | 960 × 540（16:9） | 央视春晚案例封面 | 春晚 / 大型晚会画面 |
| `case-record.jpg` | 960 × 540 | 都江堰纪录封面 | 万架齐飞现场 |
| `case-guinness.jpg` | 960 × 540 | 吉尼斯案例封面 | 2020 吉尼斯现场 |
| `case-tju.jpg` | 960 × 540 | 天津大学案例封面 | 校庆现场 |
| `qr-wechat.png` | 600 × 600 以上 | 底部 / 成功弹层二维码 | **新增文件**。企业微信或顾问二维码；未提供时显示占位图标 |

> 当前仓库中的图片是**程序生成的夜景占位图**（`tools/make_placeholders.py`），不是真实演出照片，上线前请全部替换。替换时请同时确认版权/客户授权。

---

## 5. 视频替换

视频放入 `assets/video/`，**按文件名自动生效**，详见 [`assets/video/README.md`](assets/video/README.md)。

| 文件名 | 位置 | 建议规格 |
| --- | --- | --- |
| `hero.mp4` | 首屏背景视频 | 1080 × 1920、H.264、无声循环、≤ 8 MB |
| `case-spring.mp4` | 2024 央视春晚案例 | 1920 × 1080、≤ 30 MB |
| `case-record.mp4` | 2026 都江堰纪录现场 | 同上 |
| `case-guinness.mp4` | 2020 吉尼斯案例 | 同上 |
| `case-tju.mp4` | 天津大学 130 周年案例 | 同上 |

- 首屏视频缺失时显示 `hero.jpg` 海报，不影响页面；
- 案例视频缺失时弹层显示「完整案例视频请联系顾问获取」的兜底画面；
- 路径/扩展名可在 `assets/js/config.js` 的 `videoBase`、`videoExt` 中调整。

---

## 6. 表单接口与配置

上线前主要修改 **`assets/js/config.js`**：

```js
window.EFY_CONFIG = {
  phone: "400-0360-008",              // 页面展示电话
  phoneRaw: "4000360008",             // tel: 拨号号码
  email: "efyishow@efy-tech.com",     // 商务邮箱
  address: "天津经济技术开发区南海路 156 号通厂 24 号",

  api: "",                            // 留资接口；留空 = 本地演示
  apiTimeout: 12000,
  smsApi: "",                         // 验证码接口；留空 = 演示模式
  smsDemo: true,                      // 演示模式：任意 6 位数字可通过
  requireCode: true,                  // 是否强制校验验证码
  codeCountdown: 60,                  // 倒计时秒数

  videoBase: "assets/video/",
  videoExt: "mp4",
  debugTrack: true,                   // 控制台打印埋点
};
```

### 6.1 留资接口约定

页面会向 `api` 发起 `POST application/json`，请求体示例：

```json
{
  "name": "张先生",
  "phone": "13800138000",
  "code": "123456",
  "need": "演出策划",
  "fleet": "500 架",
  "company": "某某文旅集团",
  "scenes": ["景区驻场", "品牌发布"],
  "interest": "MODEL X",
  "source": "efy-h5",
  "page": "https://example.com/h5/",
  "referrer": "",
  "utm": { "utm_source": "wechat" },
  "ts": "2026-11-03T01:26:00.000Z"
}
```

期望返回：

```json
{ "code": 0, "msg": "ok" }
```

- 2xx 且 `code` 为 `0` / `200`（或未返回 `code`）视为成功；
- 失败时返回非 2xx，或 `code` 非 0，`msg` 会展示在表单下方；
- 需要后端开启 CORS（允许 H5 域名），并对手机号做服务端校验与频率限制；
- 生产环境务必在服务端再次校验短信验证码，不要只依赖前端。

### 6.2 短信验证码

- **演示模式（默认）**：`smsDemo: true` 时不真正发短信，任意 6 位数字可通过前端校验；点击「获取验证码」会出现提示文案。
- **正式接入**：把 `smsApi` 设置为发送接口（`POST { phone }`），并将 `smsDemo` 改为 `false`；服务端在提交留资时校验验证码。
- 若希望降低留资门槛，可将 `requireCode` 改为 `false`（前端不再要求验证码，但接口仍建议校验手机号真实性）。

### 6.3 「一键填写」桥接

页面优先调用 App / 微信 WebView 注入的桥接方法：

```js
// 任选其一
window.EFYBridge.getPhoneNumber()  // 返回手机号字符串或 Promise
window.EFY.getPhoneNumber()
```

没有桥接时自动降级为「请手动输入手机号」，不会填入假数据。

### 6.4 本地演示数据

`api` 留空时，提交只会写入当前浏览器的 `localStorage`（key：`efy_h5_leads_v1`，最多 10 条），用于演示；
不会上传到任何服务器。正式上线前请接好接口。

---

## 7. 联系方式 / 备案信息

- 电话 `400-0360-008`、邮箱 `efyishow@efy-tech.com`、地址来自一飞智控官网「联系我们」页；
- 页脚备案号 `津ICP备15007608号-1` 为一飞官网备案号，**部署到新域名时请替换为该域名对应的备案号**；
- 页面中的电话、邮箱、地址会由 `config.js` 自动注入；HTML 里保留了一份无 JS 时的兜底文案，改完 config 如担心不一致可同步修改；
- 企业微信二维码：新增 `assets/img/qr-wechat.png` 即可自动替换占位图标（失败时显示图标占位，不会破图）。

---

## 8. 数据来源与合规

页面展示的数字与案例均有公开来源，详细口径与措辞建议见 [`docs/content-plan.md`](docs/content-plan.md) 第 6 节。核心来源：

| 内容 | 来源 |
| --- | --- |
| 3,000+ 场 / 200+ 城市 / 100 万+ 架次 / 10 万+ 小时 | 一飞智控官网「编队表演」「全球布局」 |
| 10,000㎡ 总部 / 140+ 发明专利 / 5 大分支机构 / 2015 成立 | 一飞智控官网「公司简介」 |
| 2026 都江堰 33,615 架、三项吉尼斯；一飞供机 1 万多架（四家最多） | 中国新闻网 2026-05-21、科技日报 2026-06-16、苏州日报 2026-05-22 |
| 2020 吉尼斯 600 架、26 分 19 秒「最长时长无人机表演动画」 | 央视网 2020-12-18、央广网 2020-12-18 |
| 2024 央视春晚 2,500 架 | 津滨网 2024-02-12、北方网 2024-02-22 |
| 天津大学 130 周年 2,000 架 | 一飞智控官网新闻 |
| 机队规模参考、单场 10–20 分钟、2–4 周、风速 5 m/s | 一飞智控官网「表演报价」 |
| AGILE BEE III 参数（550 g、15–20 min、抗风 5 级等） | 一飞智控官网产品页 |
| 官网产品与飞控（Finix） | 一飞智控官网产品导航 |

**重要口径**：2026 年都江堰 33,615 架纪录的主办/执飞方为 MOVA 驭风者，一飞智控是四家供机企业之一（供机 1 万多架，数量最多）。页面已按「参与供机」表述，请勿在后续传播中改成「一飞创下 33,615 架纪录」。

**合规建议**

- 发布前请公司法务/市场审核全部数字与措辞，避免绝对化用语；
- 隐私条款需替换为公司合规定稿，并补充运营主体、联系方式、存储期限与用户权利；
- 案例图片/视频需取得客户与演出方的公开传播授权；
- 若投放广告，请保留各项数据的原始来源截图备查。

---

## 9. 部署

### 静态托管

把 `efy-h5` 整个目录上传即可。Nginx 示例：

```nginx
server {
  listen 443 ssl http2;
  server_name show.example.com;
  root /var/www/efy-h5;
  index index.html;

  # 视频支持 Range，避免拖动进度条失败
  location ~* \.(mp4|webm)$ {
    add_header Accept-Ranges bytes;
    add_header Cache-Control "public, max-age=604800";
  }

  location ~* \.(jpg|jpeg|png|webp|svg|css|js)$ {
    add_header Cache-Control "public, max-age=31536000, immutable";
  }

  location / {
    try_files $uri $uri/ /index.html;
  }
}
```

### 上线检查

- **HTTPS**：微信内打开、摄像头/定位等能力与分享都要求 HTTPS；
- **MIME**：确保 `.mp4` 为 `video/mp4`、`.webp` 为 `image/webp`；
- **压缩**：开启 gzip / brotli（CSS/JS/HTML），图片可转 WebP（同时保留 jpg 兜底）；
- **分享卡片**：`index.html` 已包含 `og:title` / `og:description` / `og:image`，请把 `og:image` 改为**绝对 URL**；
  如需微信自定义分享标题/缩略图，接入微信 JSSDK（需公众号后台配置 JS 安全域名）；
- **域名备案**：使用国内服务器/域名需完成 ICP 备案，并替换页脚备案号；
- **视频 CDN**：视频较大时建议放 CDN，保留 `Accept-Ranges`；
- **二维码**：上线前放入真实的 `assets/img/qr-wechat.png`。

---

## 10. 兼容性、性能与无障碍

- **兼容**：iOS Safari 14+、微信内置浏览器、Android Chrome/WebView、桌面 Chrome/Edge/Safari；
- **首屏**：预加载 `hero.jpg`，图片 `loading="lazy"`，字体使用系统中文字体，无外部请求；
- **体积**：当前整页（含 15 张占位图）约 1.5 MB；替换真实素材后建议首屏 ≤ 500 KB、整页 ≤ 3 MB；
- **动效**：支持 `prefers-reduced-motion: reduce`，会关闭视差、滚动入场与跑马灯；
- **键盘/读屏**：表单 label 关联、错误提示 `role="alert"`、弹层焦点陷阱、ESC 关闭、跳转主内容链接；
- **安全区**：顶部/底部使用 `env(safe-area-inset-*)`，适配刘海屏与底部小白条；
- **视频自动播放**：使用 `muted` + `playsinline`；若系统限制自动播放，会保留海报图，不影响阅读。

---

## 11. 埋点

页面会把事件推入 `window.dataLayer`（同时可在控制台查看）：

| 事件 | 触发时机 | 主要参数 |
| --- | --- | --- |
| `page:view` | 页面加载 | `path`、`utm` |
| `click` | 点击带 `data-track` 的按钮 | `name` |
| `form:chip` | 选择需求/规模/场景 | `group`、`value`、`on` |
| `form:sms` | 点击获取验证码 | `demo` |
| `form:submit` | 提交表单 | `need`、`fleet`、`scenes` |
| `form:success` / `form:error` | 提交结果 | 需求信息 / 错误信息 |
| `product:interest` | 点击产品咨询 | `product` |
| `scene:select` | 点击场景卡 | `scene` |
| `case:open` | 打开案例弹层 | `id` |
| `modal:open` / `modal:close` | 弹层开关 | `id` |
| `faq:toggle` | 展开/收起 FAQ | `open` |

接入 GA4 / 神策 / 友盟时，在 `init()` 里消费 `dataLayer` 或替换 `track()` 实现即可；上线后可把 `debugTrack` 设为 `false`。

---

## 12. 开发辅助脚本（可选，可删）

- `tools/make_placeholders.py`：用 Pillow 生成文章中的夜景占位图（需要 Python + Pillow）；
  ```bash
  python tools/make_placeholders.py
  ```
- `tools/capture.mjs`：用无头 Edge 渲染页面、按区块截图，并自动跑一遍「表单填写 → 提交 → 成功弹层」「案例弹层」「FAQ」「360px 溢出」自检；
  ```bash
  node tools/capture.mjs .
  ```
  脚本内的 Edge 路径与调试端口可按本机环境修改；截图输出到 `shots/`（已被 `.gitignore` 排除）。

---

## 13. 上线前 TODO

- [ ] 替换 `assets/img/` 下全部占位图（真实演出/产品图，确认版权）
- [ ] 放入 `assets/video/hero.mp4` 与 4 个案例视频（或先删掉案例视频位）
- [ ] 新增 `assets/img/qr-wechat.png`（企业微信/顾问二维码）
- [ ] 配置 `config.js`：`api`、`smsApi`、`smsDemo`、联系方式
- [ ] 核对电话、邮箱、地址、备案号（新域名需替换）
- [ ] 法务审核隐私条款与全部数据表述（尤其是 33,615 架纪录口径）
- [ ] 确认案例素材已获客户/演出方授权
- [ ] 微信 JSSDK 分享卡片（可选）与 `og:image` 绝对地址
- [ ] 在微信内置浏览器、iOS Safari、Android Chrome 各走一遍表单
- [ ] 接入统计平台，验证 `dataLayer` 事件
- [ ] 开启 gzip/brotli 与静态资源缓存，检查首屏加载

---

## 14. 说明

- 本页面中的夜景图片为程序生成的占位素材，并非一飞智控真实演出照片；上线请替换。
- 页面内容框架参考同行公开 H5，但文案、视觉与代码均为本项目的独立实现。
- 页面中的公司信息、案例与数据来自一飞智控官网及公开报道，仅用于本项目的展示与留资场景；具体以官方最新口径与合同为准。
- 一飞智控（EFY）为其所属公司的商标/名称，本页面用于该公司自有营销物料。
