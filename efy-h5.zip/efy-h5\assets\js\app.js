/* ==========================================================================
   一飞智控 EFY · 无人机集群表演 H5
   原生 JavaScript，无第三方依赖
   ========================================================================== */
(function () {
  "use strict";

  var DEFAULTS = {
    phone: "400-0360-008",
    phoneRaw: "4000360008",
    email: "efyishow@efy-tech.com",
    address: "天津经济技术开发区南海路 156 号通厂 24 号",
    api: "",
    apiTimeout: 12000,
    smsApi: "",
    smsDemo: true,
    requireCode: true,
    codeCountdown: 60,
    videoBase: "assets/video/",
    videoExt: "mp4",
    debugTrack: true,
  };

  var CONFIG = Object.assign({}, DEFAULTS, window.EFY_CONFIG || {});
  if (!CONFIG.phoneRaw) CONFIG.phoneRaw = String(CONFIG.phone || "").replace(/\D/g, "");

  var $ = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var numberFmt = new Intl.NumberFormat("en-US");

  var state = {
    interest: "",
    submitting: false,
    codeLeft: 0,
    codeTimer: null,
    activeModal: null,
    lastFocus: null,
    toastTimer: null,
    caseTimer: null,
    caseSettled: false,
  };

  var CASES = {
    spring: {
      tag: "北京 · 央视春晚 · 2024",
      title: "2024 央视春晚 · 2,500 架",
      desc: "除夕倒计时画面中，2,500 架无人机组成“2024 龙年大吉”与双手比心，全部由一飞研发生产。",
      image: "assets/img/case-spring.jpg",
    },
    record: {
      tag: "四川 · 都江堰 · 2026",
      title: "2026 都江堰 · 33,615 架纪录现场",
      desc: "33,615 架无人机同时升空，创下三项吉尼斯世界纪录。一飞智控是四家供机企业中供机数量最多的一家，提供 1 万多架。",
      image: "assets/img/case-record.jpg",
    },
    guinness: {
      tag: "天津 · 天津大学 · 2020",
      title: "2020 吉尼斯 · 26 分 19 秒",
      desc: "600 架“敏捷蜂Ⅱ型”在天津大学完成 26 分 19 秒连续动画飞行，创下“最长时长无人机表演的动画”吉尼斯世界纪录。",
      image: "assets/img/case-guinness.jpg",
    },
    tju: {
      tag: "天津 · 天津大学 · 2025",
      title: "2025 天津大学 130 周年 · 2,000 架",
      desc: "2,000 架无人机点亮天津大学 130 周年校庆之夜，用一场专属的星空叙事为百卅校庆献礼。",
      image: "assets/img/case-tju.jpg",
    },
  };

  /* ------------------------------------------------------------------ 工具 */
  function formatNum(n) { return numberFmt.format(Math.round(n)); }

  function delay(ms) { return new Promise(function (resolve) { setTimeout(resolve, ms); }); }

  function debounce(fn, wait) {
    var t;
    return function () {
      var args = arguments, ctx = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(ctx, args); }, wait);
    };
  }

  function rafThrottle(fn) {
    var ticking = false;
    return function () {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        ticking = false;
        fn();
      });
    };
  }

  function getUtm() {
    var params = new URLSearchParams(window.location.search);
    var utm = {};
    ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"].forEach(function (key) {
      var v = params.get(key);
      if (v) utm[key] = v;
    });
    return utm;
  }

  function track(name, extra) {
    var payload = Object.assign({ event: name, ts: Date.now() }, extra || {});
    if (CONFIG.debugTrack) console.info("[EFY]", payload);
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push(payload);
  }

  function maskPhone(phone) {
    return String(phone || "").replace(/^(\d{3})\d{4}(\d{4})$/, "$1****$2");
  }

  function showToast(message, duration) {
    var toast = $("#toast");
    if (!toast) return;
    toast.textContent = message;
    clearTimeout(state.toastTimer);
    toast.classList.add("is-visible");
    state.toastTimer = setTimeout(function () {
      toast.classList.remove("is-visible");
    }, duration || 2600);
  }

  function focusEl(el) {
    if (!el) return;
    try {
      el.focus({ preventScroll: true });
    } catch (err) {
      el.focus();
    }
  }

  function scrollToConsult(shouldFocus) {
    var target = document.getElementById("consult");
    if (!target) return;
    target.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "start" });
    if (shouldFocus) {
      setTimeout(function () {
        focusEl(document.getElementById("f-name"));
      }, reduceMotion ? 80 : 700);
    }
  }

  /* ------------------------------------------------------------------ 配置注入 */
  function applyConfig() {
    $$("[data-config]").forEach(function (el) {
      var key = el.getAttribute("data-config");
      if (key === "phoneText") el.textContent = CONFIG.phone;
      else if (key === "emailText") el.textContent = CONFIG.email;
      else if (key === "address") el.textContent = CONFIG.address;
    });
    $$("[data-config-href]").forEach(function (el) {
      var key = el.getAttribute("data-config-href");
      if (key === "phone") el.setAttribute("href", "tel:" + CONFIG.phoneRaw);
      else if (key === "email") el.setAttribute("href", "mailto:" + CONFIG.email);
    });
    $$("[data-qr]").forEach(function (img) {
      var markMissing = function () { img.setAttribute("data-missing", ""); };
      if (img.complete && img.naturalWidth === 0) markMissing();
      img.addEventListener("error", markMissing);
      img.addEventListener("load", function () { img.removeAttribute("data-missing"); });
    });
  }

  /* ------------------------------------------------------------------ 顶部与滚动 */
  function initScrollUI() {
    var header = $("[data-header]");
    var progress = $("#scrollProgress");
    var hero = $(".hero");
    var heroInner = $(".hero__inner");
    var heroPoster = $(".hero__poster");
    var toTop = $("#toTop");

    var update = function () {
      var y = window.pageYOffset || document.documentElement.scrollTop || 0;
      if (header) header.classList.toggle("is-scrolled", y > 16);

      if (progress) {
        var max = document.documentElement.scrollHeight - window.innerHeight;
        progress.style.width = max > 0 ? Math.min(100, (y / max) * 100).toFixed(2) + "%" : "0%";
      }

      if (hero && heroInner && !reduceMotion && y < window.innerHeight * 1.25) {
        heroInner.style.transform = "translate3d(0," + (y * 0.12).toFixed(1) + "px,0)";
        heroInner.style.opacity = String(Math.max(0, 1 - y / (window.innerHeight * 0.92)));
        if (heroPoster) {
          heroPoster.style.transform = "scale(1.04) translate3d(0," + (y * 0.16).toFixed(1) + "px,0)";
        }
      }

      if (toTop) toTop.classList.toggle("is-visible", y > 1400);
    };

    window.addEventListener("scroll", rafThrottle(update), { passive: true });
    window.addEventListener("resize", debounce(update, 150));
    update();

    if (toTop) {
      toTop.addEventListener("click", function () {
        window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
      });
    }
  }

  /* ------------------------------------------------------------------ 滚动入场 */
  function initReveal() {
    var items = $$(".reveal");
    if (!items.length) return;
    if (!("IntersectionObserver" in window)) {
      items.forEach(function (el) { el.classList.add("is-visible"); });
      return;
    }
    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -6% 0px" }
    );
    items.forEach(function (el) { observer.observe(el); });
  }

  /* ------------------------------------------------------------------ 数字滚动 */
  function initCounters() {
    var counters = $$("[data-count]");
    if (!counters.length) return;

    function animate(el) {
      var target = parseInt(el.getAttribute("data-count"), 10) || 0;
      var suffix = el.getAttribute("data-suffix") || "";
      if (reduceMotion || target === 0) {
        el.textContent = formatNum(target) + suffix;
        return;
      }
      var start = null;
      var duration = 1500;
      function frame(now) {
        if (start === null) start = now;
        var progress = Math.min(1, (now - start) / duration);
        var eased = 1 - Math.pow(1 - progress, 4);
        el.textContent = formatNum(target * eased) + suffix;
        if (progress < 1) {
          requestAnimationFrame(frame);
        } else {
          el.textContent = formatNum(target) + suffix;
        }
      }
      requestAnimationFrame(frame);
    }

    if (!("IntersectionObserver" in window)) {
      counters.forEach(animate);
      return;
    }
    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          animate(entry.target);
          observer.unobserve(entry.target);
        });
      },
      { threshold: 0.5 }
    );
    counters.forEach(function (el) { observer.observe(el); });
  }

  /* ------------------------------------------------------------------ 首屏视频 */
  function initHeroVideo() {
    var hero = $(".hero");
    var video = $(".hero__video");
    if (!hero || !video) return;

    var markReady = function () {
      hero.classList.add("is-video-ready");
    };
    var markFailed = function () {
      hero.classList.remove("is-video-ready");
      video.style.display = "none";
    };

    video.addEventListener("loadeddata", markReady);
    video.addEventListener("playing", markReady);
    video.addEventListener("error", markFailed);
    $$("source", video).forEach(function (source) {
      source.addEventListener("error", markFailed);
    });

    // 自动播放受限时保持海报图
    var attempt = video.play();
    if (attempt && typeof attempt.catch === "function") attempt.catch(function () {});

    // 极端情况下（文件缺失但不派发 error）兜底
    setTimeout(function () {
      if (video.readyState < 2) markFailed();
    }, 5000);

    document.addEventListener("visibilitychange", function () {
      if (document.hidden) {
        video.pause();
      } else {
        var p = video.play();
        if (p && typeof p.catch === "function") p.catch(function () {});
      }
    });
  }

  /* ------------------------------------------------------------------ 表单基础 */
  function fieldWrap(name) { return document.querySelector('[data-field="' + name + '"]'); }

  function setError(name, message) {
    var wrap = fieldWrap(name);
    if (!wrap) return;
    wrap.classList.add("has-error");
    var error = wrap.querySelector(".field__error");
    if (error) error.textContent = message || "";
    var input = wrap.querySelector("input");
    if (input) input.setAttribute("aria-invalid", "true");
  }

  function clearError(name) {
    var wrap = fieldWrap(name);
    if (!wrap) return;
    wrap.classList.remove("has-error");
    var error = wrap.querySelector(".field__error");
    if (error) error.textContent = "";
    var input = wrap.querySelector("input");
    if (input) input.removeAttribute("aria-invalid");
  }

  function setAgreeError(message) {
    var error = document.getElementById("err-agree");
    if (error) error.textContent = message || "";
  }

  function getGroupValues(groupName) {
    var group = document.querySelector('.chips[data-group="' + groupName + '"]');
    if (!group) return [];
    return $$('.chip[aria-pressed="true"]', group).map(function (chip) {
      return chip.getAttribute("data-value");
    });
  }

  function setGroupValue(groupName, values) {
    var group = document.querySelector('.chips[data-group="' + groupName + '"]');
    if (!group) return;
    $$(".chip", group).forEach(function (chip) {
      chip.setAttribute("aria-pressed", values.indexOf(chip.getAttribute("data-value")) > -1 ? "true" : "false");
    });
  }

  function phoneValid(value) {
    return /^1[3-9]\d{9}$/.test(String(value || "").trim());
  }

  function collectPayload() {
    var form = document.getElementById("leadForm");
    var payload = {
      name: (document.getElementById("f-name").value || "").trim(),
      phone: (document.getElementById("f-phone").value || "").trim(),
      code: (document.getElementById("f-code").value || "").trim(),
      need: getGroupValues("need")[0] || "",
      fleet: getGroupValues("fleet")[0] || "",
      company: (document.getElementById("f-company").value || "").trim(),
      scenes: getGroupValues("scenes"),
      interest: state.interest,
      source: "efy-h5",
      page: window.location.href,
      referrer: document.referrer || "",
      utm: getUtm(),
      ts: new Date().toISOString(),
    };
    return payload;
  }

  function initChips() {
    $$(".chips").forEach(function (group) {
      var single = group.getAttribute("data-single") === "true";
      group.addEventListener("click", function (event) {
        var chip = event.target.closest(".chip");
        if (!chip || !group.contains(chip)) return;
        var pressed = chip.getAttribute("aria-pressed") === "true";
        if (single) {
          $$(".chip", group).forEach(function (other) {
            other.setAttribute("aria-pressed", "false");
          });
          chip.setAttribute("aria-pressed", pressed ? "false" : "true");
        } else {
          chip.setAttribute("aria-pressed", pressed ? "false" : "true");
        }
        if (group.getAttribute("data-group") === "need") clearError("need");
        track("form:chip", {
          group: group.getAttribute("data-group"),
          value: chip.getAttribute("data-value"),
          on: chip.getAttribute("aria-pressed") === "true",
        });
      });
    });
  }

  function clearInterest() {
    state.interest = "";
    var bar = document.getElementById("interestBar");
    var text = document.getElementById("interestText");
    var input = document.getElementById("f-interest");
    if (bar) bar.hidden = true;
    if (text) text.textContent = "";
    if (input) input.value = "";
  }

  function initInterest() {
    $$("[data-interest]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        state.interest = btn.getAttribute("data-interest") || "";
        document.getElementById("interestText").textContent = state.interest;
        document.getElementById("f-interest").value = state.interest;
        document.getElementById("interestBar").hidden = false;
        track("product:interest", { product: state.interest });
        showToast("已选择「" + state.interest + "」，填写需求获取详细资料", 2400);
        scrollToConsult(true);
      });
    });
    var clear = document.getElementById("clearInterest");
    if (clear) {
      clear.addEventListener("click", function () {
        clearInterest();
        showToast("已取消产品选择");
      });
    }
  }

  function initSceneShortcuts() {
    $$("[data-scene]").forEach(function (card) {
      card.addEventListener("click", function () {
        var value = card.getAttribute("data-scene");
        if (!value) return;
        setGroupValue("scenes", [value]);
        track("scene:select", { scene: value });
        showToast("已选中「" + value + "」场景，填写需求获取方案", 2600);
        scrollToConsult(true);
      });
    });
  }

  function initPhoneInput() {
    var phone = document.getElementById("f-phone");
    if (!phone) return;
    phone.addEventListener("input", function () {
      var digits = phone.value.replace(/\D/g, "");
      if (digits.length > 11 && digits.indexOf("86") === 0) digits = digits.slice(2);
      phone.value = digits.slice(0, 11);
      clearError("phone");
    });
    phone.addEventListener("blur", function () {
      if (phone.value && !phoneValid(phone.value)) setError("phone", "请填写 11 位手机号");
    });

    var fill = document.getElementById("fillPhone");
    if (!fill) return;
    fill.addEventListener("click", function () {
      var bridge = window.EFYBridge || null;
      var getter = bridge && typeof bridge.getPhoneNumber === "function" ? bridge.getPhoneNumber : null;
      if (!getter && window.EFY && typeof window.EFY.getPhoneNumber === "function") {
        getter = window.EFY.getPhoneNumber;
      }
      if (!getter) {
        focusEl(phone);
        showToast("当前环境不支持一键填写，请手动输入手机号");
        return;
      }
      Promise.resolve()
        .then(function () { return getter.call(bridge || window.EFY); })
        .then(function (result) {
          var digits = String(result || "").replace(/\D/g, "");
          if (digits.length > 11 && digits.indexOf("86") === 0) digits = digits.slice(2);
          if (!phoneValid(digits)) throw new Error("invalid");
          phone.value = digits;
          clearError("phone");
          showToast("手机号已填入");
          track("form:phone:auto");
        })
        .catch(function () {
          focusEl(phone);
          showToast("未能获取手机号，请手动输入");
        });
    });
  }

  function updateSendButton() {
    var btn = document.getElementById("sendCode");
    if (!btn) return;
    if (state.codeLeft > 0) {
      btn.textContent = state.codeLeft + "s";
      btn.disabled = true;
    } else {
      btn.textContent = "获取验证码";
      btn.disabled = false;
    }
  }

  function startCountdown(seconds) {
    state.codeLeft = seconds;
    updateSendButton();
    clearInterval(state.codeTimer);
    state.codeTimer = setInterval(function () {
      state.codeLeft -= 1;
      if (state.codeLeft <= 0) {
        state.codeLeft = 0;
        clearInterval(state.codeTimer);
        state.codeTimer = null;
      }
      updateSendButton();
    }, 1000);
  }

  function resetCodeState() {
    clearInterval(state.codeTimer);
    state.codeTimer = null;
    state.codeLeft = 0;
    updateSendButton();
  }

  function postJSON(url, payload) {
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, CONFIG.apiTimeout);
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    }).finally(function () { clearTimeout(timer); });
  }

  function initSMS() {
    var btn = document.getElementById("sendCode");
    var code = document.getElementById("f-code");
    if (!btn || !code) return;

    code.addEventListener("input", function () {
      code.value = code.value.replace(/\D/g, "").slice(0, 6);
      clearError("code");
    });

    btn.addEventListener("click", function () {
      if (state.codeLeft > 0) return;
      var phone = document.getElementById("f-phone").value.trim();
      if (!phoneValid(phone)) {
        setError("phone", "请先填写正确的手机号");
        focusEl(document.getElementById("f-phone"));
        showToast("请先填写 11 位手机号");
        return;
      }
      clearError("phone");
      btn.disabled = true;
      btn.textContent = "发送中…";

      var request = CONFIG.smsApi
        ? postJSON(CONFIG.smsApi, { phone: phone }).then(function (res) {
            if (!res.ok) throw new Error("sms failed");
          })
        : delay(650);

      request
        .then(function () {
          startCountdown(CONFIG.codeCountdown || 60);
          track("form:sms", { demo: !CONFIG.smsApi });
          showToast(
            CONFIG.smsApi || !CONFIG.smsDemo
              ? "验证码已发送，请查收短信"
              : "验证码已发送（演示模式：输入任意 6 位数字）",
            3600
          );
        })
        .catch(function (error) {
          console.warn("[EFY] 验证码发送失败", error);
          btn.disabled = false;
          btn.textContent = "获取验证码";
          showToast("验证码发送失败，请稍后重试");
        });
    });
  }

  function validateForm(showErrors) {
    var name = document.getElementById("f-name").value.trim();
    var phone = document.getElementById("f-phone").value.trim();
    var code = document.getElementById("f-code").value.trim();
    var agree = document.getElementById("f-agree").checked;
    var firstInvalid = null;
    var valid = true;

    if (name.length < 2) {
      valid = false;
      if (showErrors) setError("name", "请填写你的称呼（至少 2 个字）");
      firstInvalid = firstInvalid || document.getElementById("f-name");
    } else if (showErrors) clearError("name");

    if (!phoneValid(phone)) {
      valid = false;
      if (showErrors) setError("phone", "请填写正确的 11 位手机号");
      firstInvalid = firstInvalid || document.getElementById("f-phone");
    } else if (showErrors) clearError("phone");

    if (CONFIG.requireCode && !/^\d{6}$/.test(code)) {
      valid = false;
      if (showErrors) setError("code", "请输入 6 位短信验证码");
      firstInvalid = firstInvalid || document.getElementById("f-code");
    } else if (showErrors) clearError("code");

    if (!agree) {
      valid = false;
      if (showErrors) setAgreeError("请先阅读并同意《个人信息与隐私保护条款》");
      firstInvalid = firstInvalid || document.getElementById("f-agree");
    } else if (showErrors) setAgreeError("");

    if (!valid && showErrors) focusEl(firstInvalid);
    return valid;
  }

  function saveLocalLead(payload) {
    try {
      var key = "efy_h5_leads_v1";
      var list = JSON.parse(window.localStorage.getItem(key) || "[]");
      if (!Array.isArray(list)) list = [];
      list.unshift(Object.assign({}, payload, { demo: true }));
      window.localStorage.setItem(key, JSON.stringify(list.slice(0, 10)));
    } catch (error) {
      console.warn("[EFY] 本地演示数据写入失败", error);
    }
  }

  function submitLead(payload) {
    if (!CONFIG.api) {
      saveLocalLead(payload);
      return delay(900).then(function () { return { ok: true, demo: true }; });
    }
    return postJSON(CONFIG.api, payload).then(function (res) {
      if (!res.ok) throw new Error("接口返回 " + res.status);
      return res
        .json()
        .catch(function () { return {}; })
        .then(function (data) {
          if (data && data.code !== undefined && [0, 200, "0", "200"].indexOf(data.code) === -1) {
            throw new Error(data.msg || data.message || "提交失败");
          }
          return data || {};
        });
    });
  }

  function setStatus(message, isError) {
    var status = document.getElementById("formStatus");
    if (!status) return;
    status.textContent = message || "";
    status.classList.toggle("is-error", !!isError);
  }

  function showSuccess(payload) {
    var meta = document.getElementById("successMeta");
    if (meta) {
      meta.textContent = "";
      var rows = [
        ["姓名", payload.name],
        ["手机号", maskPhone(payload.phone)],
        ["需求", [payload.need, payload.fleet].filter(Boolean).join(" · ")],
        ["场景", (payload.scenes || []).join("、")],
        ["意向产品", payload.interest],
      ].filter(function (row) { return row[1]; });
      rows.forEach(function (row) {
        var div = document.createElement("div");
        var dt = document.createElement("dt");
        var dd = document.createElement("dd");
        dt.textContent = row[0];
        dd.textContent = row[1];
        div.appendChild(dt);
        div.appendChild(dd);
        meta.appendChild(div);
      });
    }
    openModal("successModal");
  }

  function initForm() {
    var form = document.getElementById("leadForm");
    if (!form) return;

    ["f-name", "f-phone", "f-code"].forEach(function (id) {
      var input = document.getElementById(id);
      if (!input) return;
      input.addEventListener("input", function () {
        clearError(id.replace("f-", ""));
        if (id === "f-name" && input.value.trim().length >= 2) clearError("name");
      });
    });

    document.getElementById("f-agree").addEventListener("change", function () {
      if (this.checked) setAgreeError("");
    });

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      if (state.submitting) return;
      if (!validateForm(true)) {
        showToast("请检查带 * 的必填信息");
        track("form:invalid");
        return;
      }

      var payload = collectPayload();
      state.submitting = true;
      form.classList.add("is-submitting");
      setStatus("正在提交，请稍候…");
      track("form:submit", { need: payload.need, fleet: payload.fleet, scenes: payload.scenes });

      submitLead(payload)
        .then(function () {
          track("form:success", { need: payload.need, fleet: payload.fleet });
          setStatus("");
          form.classList.remove("is-submitting");
          form.reset();
          $$(".chip[aria-pressed='true']").forEach(function (chip) {
            chip.setAttribute("aria-pressed", "false");
          });
          clearInterest();
          clearError("name");
          clearError("phone");
          clearError("code");
          setAgreeError("");
          resetCodeState();
          showSuccess(payload);
        })
        .catch(function (error) {
          console.error("[EFY] 提交失败", error);
          form.classList.remove("is-submitting");
          setStatus("提交失败，请稍后重试，或直接致电顾问", true);
          showToast("提交失败，请稍后重试");
          track("form:error", { message: String(error && error.message) });
        })
        .finally(function () {
          state.submitting = false;
        });
    });
  }

  /* ------------------------------------------------------------------ 弹层 */
  function stopCaseVideo() {
    var video = document.getElementById("caseVideo");
    if (!video) return;
    video.pause();
    video.onloadeddata = null;
    video.onerror = null;
    video.removeAttribute("src");
    video.load();
    video.hidden = true;
  }

  function openModal(id) {
    var modal = document.getElementById(id);
    if (!modal) return;
    if (state.activeModal && state.activeModal !== modal) closeModal(state.activeModal);
    state.lastFocus = document.activeElement;
    modal.hidden = false;
    document.body.classList.add("modal-open");
    requestAnimationFrame(function () { modal.classList.add("is-open"); });
    state.activeModal = modal;
    var target = modal.querySelector("[data-autofocus], .modal__close, button, a[href]");
    setTimeout(function () { focusEl(target || modal); }, 60);
    track("modal:open", { id: id });
  }

  function closeModal(modal) {
    modal = modal || state.activeModal;
    if (!modal) return;
    if (modal.id === "caseModal") stopCaseVideo();
    modal.classList.remove("is-open");
    document.body.classList.remove("modal-open");
    state.activeModal = null;
    setTimeout(function () { modal.hidden = true; }, 160);
    if (state.lastFocus && typeof state.lastFocus.focus === "function") {
      var target = state.lastFocus;
      state.lastFocus = null;
      setTimeout(function () { focusEl(target); }, 20);
    }
    track("modal:close", { id: modal.id });
  }

  function trapFocus(event) {
    if (!state.activeModal || event.key !== "Tab") return;
    var focusables = $$(
      'a[href], button:not([disabled]), input:not([disabled]), textarea, select, [tabindex]:not([tabindex="-1"])',
      state.activeModal
    ).filter(function (el) { return el.offsetParent !== null; });
    if (!focusables.length) return;
    var first = focusables[0];
    var last = focusables[focusables.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      focusEl(last);
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      focusEl(first);
    }
  }

  function initModals() {
    document.addEventListener("click", function (event) {
      var closer = event.target.closest("[data-close-modal]");
      var opener = event.target.closest("[data-open-modal]");
      var consultAfter = event.target.closest("[data-consult-after]");

      if (opener) {
        event.preventDefault();
        openModal(opener.getAttribute("data-open-modal"));
        return;
      }
      if (closer) closeModal(closer.closest(".modal"));
      if (consultAfter) setTimeout(function () { scrollToConsult(true); }, 240);
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") closeModal();
      trapFocus(event);
    });
  }

  function openCase(id, trigger) {
    var data = CASES[id];
    if (!data) return;

    var tag = document.getElementById("caseModalTag");
    var title = document.getElementById("caseModalTitle");
    var desc = document.getElementById("caseModalDesc");
    var image = document.getElementById("caseFallbackImg");
    if (tag) tag.textContent = data.tag;
    if (title) title.textContent = data.title;
    if (desc) desc.textContent = data.desc;
    if (image) image.src = data.image;

    track("case:open", { id: id });
    openModal("caseModal");
    playCaseVideo(id);
  }

  function playCaseVideo(id) {
    var video = document.getElementById("caseVideo");
    var loader = document.getElementById("caseModalLoader");
    var fallback = document.getElementById("caseModalFallback");
    if (!video || !loader || !fallback) return;

    clearTimeout(state.caseTimer);
    state.caseSettled = false;
    video.hidden = true;
    fallback.hidden = true;
    loader.hidden = false;
    video.onloadeddata = null;
    video.onerror = null;

    var showVideo = function () {
      if (state.caseSettled) return;
      state.caseSettled = true;
      clearTimeout(state.caseTimer);
      loader.hidden = true;
      video.hidden = false;
      var play = video.play();
      if (play && typeof play.catch === "function") play.catch(function () {});
    };
    var showFallback = function () {
      if (state.caseSettled) return;
      state.caseSettled = true;
      clearTimeout(state.caseTimer);
      loader.hidden = true;
      video.hidden = true;
      fallback.hidden = false;
    };

    state.caseTimer = setTimeout(showFallback, 5000);
    video.onloadeddata = showVideo;
    video.onerror = showFallback;
    video.src = CONFIG.videoBase + "case-" + id + "." + CONFIG.videoExt;
    video.load();
  }

  function initCases() {
    $$("[data-open-case]").forEach(function (trigger) {
      trigger.addEventListener("click", function () {
        openCase(trigger.getAttribute("data-open-case"), trigger);
      });
    });
  }

  /* ------------------------------------------------------------------ FAQ */
  function initFAQ() {
    var items = $$(".faq-item");
    if (!items.length) return;

    items.forEach(function (item) {
      var button = $(".faq-item__q", item);
      var panel = $(".faq-item__a", item);
      if (!button || !panel) return;

      button.addEventListener("click", function () {
        var isOpen = item.classList.contains("is-open");
        items.forEach(function (other) {
          if (other === item) return;
          if (!other.classList.contains("is-open")) return;
          other.classList.remove("is-open");
          var otherBtn = $(".faq-item__q", other);
          var otherPanel = $(".faq-item__a", other);
          if (otherBtn) otherBtn.setAttribute("aria-expanded", "false");
          if (otherPanel) otherPanel.style.maxHeight = "0px";
        });

        item.classList.toggle("is-open", !isOpen);
        button.setAttribute("aria-expanded", String(!isOpen));
        panel.style.maxHeight = isOpen ? "0px" : panel.scrollHeight + "px";
        track("faq:toggle", { open: !isOpen });
      });
    });

    window.addEventListener(
      "resize",
      debounce(function () {
        $$(".faq-item.is-open .faq-item__a").forEach(function (panel) {
          panel.style.maxHeight = panel.scrollHeight + "px";
        });
      }, 150)
    );
  }

  /* ------------------------------------------------------------------ 底部转化条 / 回到顶部 */
  function initStickyCTA() {
    var sticky = document.getElementById("stickyCta");
    var consult = document.getElementById("consult");
    if (!sticky || !consult) return;

    if (!("IntersectionObserver" in window)) return;
    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          sticky.classList.toggle("is-hidden", entry.isIntersecting);
        });
      },
      { threshold: 0.18 }
    );
    observer.observe(consult);
  }

  /* ------------------------------------------------------------------ 初始化 */
  function init() {
    applyConfig();
    initScrollUI();
    initReveal();
    initCounters();
    initHeroVideo();
    initChips();
    initInterest();
    initSceneShortcuts();
    initPhoneInput();
    initSMS();
    initForm();
    initModals();
    initCases();
    initFAQ();
    initStickyCTA();

    // 通用埋点：带 data-track 的元素点击后上报
    document.addEventListener("click", function (event) {
      var tracked = event.target.closest("[data-track]");
      if (tracked) track("click", { name: tracked.getAttribute("data-track") });
    });

    var year = new Date().getFullYear();
    $$("[data-year]").forEach(function (el) { el.textContent = year; });

    track("page:view", { path: window.location.pathname, utm: getUtm() });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // 便于调试 / 对接：控制台可用 window.EFY_H5
  window.EFY_H5 = {
    config: CONFIG,
    track: track,
    openModal: openModal,
    closeModal: closeModal,
    cases: CASES,
  };
})();
